# Copyright 2014-2020 The PySCF Developers. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# If extension plugins are installed in pyscf, search and load the pbc
# submodule in all plugins if applicable
if len(__import__('pyscf').__path__) > 1:
    __path__ = __import__('pkgutil').extend_path(__path__, __name__)

from pyscf.pbc import gto
from pyscf.pbc import scf
#from pyscf.pbc import tools

DEBUG = False

M = gto.M
